const settings = {
  packname: 'KING_NIMA',
  author: 'Bot',
  botName: "NIMA MD",
  botOwner: 'KING NIMA', // Your name
  ownerNumber: '94769268470', //Your number
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a NIMA MD bot.",
  version: "1.0.0",
};

module.exports = settings;
